package net.mooctest;

public class SparseWeightedGraph {

}
