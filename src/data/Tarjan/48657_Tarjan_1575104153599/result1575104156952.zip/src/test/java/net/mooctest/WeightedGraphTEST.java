package net.mooctest;

public class WeightedGraphTEST {

}
