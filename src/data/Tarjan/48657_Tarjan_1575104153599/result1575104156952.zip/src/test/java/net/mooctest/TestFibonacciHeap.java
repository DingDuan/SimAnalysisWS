package net.mooctest;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.Locale;

import org.junit.Test;


public class TestFibonacciHeap {

	  @Test
	  public void test00(){
		  
	  }


	@Test
	  public void test01(){
		
	  }

	  @Test
	  public void test02(){
	     
	  }

	  @Test
	  public void test03(){
		  
	  }

	  @Test
	  public void test04(){
		  
	  }

	  @Test
	  public void test05(){
		  
	  }

	  @Test
	  public void test06(){
		  
	  }

	  @Test
	  public void test07(){
		  
	  }
}
