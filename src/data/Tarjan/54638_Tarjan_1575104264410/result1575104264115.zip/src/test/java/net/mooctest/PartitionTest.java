package net.mooctest;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.LinkedList;

import org.junit.Test;

public class PartitionTest {

	
	
	@Test(timeout = 4000)
	  public void test1()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      //linkedList0.
	  }

}
