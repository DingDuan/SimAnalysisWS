package net.mooctest;

import static org.junit.Assert.*;

import java.awt.List;

import org.junit.Test;

public class ChuLiuEdmondsTest {

	@Test
	public void test() {
		
		/*Iterable<Weighted<Edge<T>>> edges0
		SparseWeightedGraph<Integer> wei;
		wei.from(edges0);
		ChuLiuEdmonds chu;
		chu.getMaxArborescence(null);*/
	}

}
