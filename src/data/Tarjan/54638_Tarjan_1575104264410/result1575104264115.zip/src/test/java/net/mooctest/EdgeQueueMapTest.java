package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

import net.mooctest.EdgeQueueMap.EdgeQueue;

public class EdgeQueueMapTest {

	@Test
	public void test() {
		
		//EdgeQueueMap.EdgeQueue<Integer> edge_0;
		//Partition<Integer> p=Partition.singletons(null);
		//EdgeQueueMap<Integer> e=new EdgeQueueMap<Integer>(p);
	}

}
