package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class DenseWeightedGraphTest {

	@Test
	public void test() {
		double [][]weights= {{1.0,2.0,3.0},{4.0,5.0,6.0}};
		//DenseWeightedGraph.from(weights);
	}

}
