package net.mooctest;
import org.junit.Test;


public class TestChuLiuEdmonds {

	@Test
	public void test() {
		
        //initialize
        //getNodes
       // merge
       // getCycle
       // addEdge
       // popBestEdge
      //  popBestEdge
      //  getMaxArborescence
	}

	
}