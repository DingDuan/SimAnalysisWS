package net.mooctest;
import org.junit.Test;


public class TestFibonacciHeap {

	@Test
	public void test() {
		FibonacciHeap<Integer,Integer> heap = FibonacciHeap.create();
        //heap.FibonacciHeap();
        //creat
       // comparator
       // clear
       // decreasePriority
       // remove
       // isEmpty
       // add
        //peekOption
       // pollOption
       // size
      //  merge
       // iterator
       // siblingsAndBelow
       // getCycle
	}

	
}
