package net.mooctest;

public class Snippet {
	 * In an arborescence, each node (other than the root) has exactly one parent. This is the map
	 * from each node to its parent.
}
