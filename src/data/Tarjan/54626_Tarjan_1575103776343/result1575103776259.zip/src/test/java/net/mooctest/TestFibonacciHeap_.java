package net.mooctest;
import org.junit.Test;


public class TestFibonacciHeap_ {

	@Test
	public void test_E() {
		FibonacciHeap<Integer,Integer> heap = FibonacciHeap.create();
		heap.add(1, 1);
		
	}

	
}
