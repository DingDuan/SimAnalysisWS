package net.mooctest;

import static org.evosuite.shaded.org.mockito.Mockito.mock;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.util.Comparator;
import java.util.function.Consumer;

import org.evosuite.runtime.ViolatedAssumptionAnswer;
import org.junit.Test;


public class FibonacciHeapTest {

	 @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.pollOption();
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      FibonacciHeap<String, Object> fibonacciHeap1 = FibonacciHeap.merge(fibonacciHeap0, fibonacciHeap0);
	      fibonacciHeap1.add("", fibonacciHeap0);
	      fibonacciHeap1.size();
	      Comparator<Object> comparator1 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	     
	      FibonacciHeap<String, FibonacciHeap<String, String>> fibonacciHeap2 = FibonacciHeap.create((Comparator<? super FibonacciHeap<String, String>>) comparator1);
	      fibonacciHeap2.iterator();
	      Comparator<Object> comparator2 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	    
	      FibonacciHeap<Object, Integer> fibonacciHeap3 = FibonacciHeap.create((Comparator<? super Integer>) comparator2);
	      FibonacciHeap<Object, Integer> fibonacciHeap4 = FibonacciHeap.merge(fibonacciHeap3, fibonacciHeap3);
	      FibonacciHeap.merge(fibonacciHeap4, fibonacciHeap4);
	      FibonacciHeap<String, FibonacciHeap<String, String>> fibonacciHeap5 = FibonacciHeap.merge(fibonacciHeap2, fibonacciHeap2);
	      fibonacciHeap5.isEmpty();
	      fibonacciHeap5.iterator();
	      fibonacciHeap5.iterator();
	      Comparator<Object> comparator3 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	     
	      Comparator<Object> comparator4 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      
	      FibonacciHeap<FibonacciHeap.Entry, Object> fibonacciHeap6 = FibonacciHeap.create((Comparator<? super Object>) comparator4);
	      FibonacciHeap<FibonacciHeap.Entry, Object> fibonacciHeap7 = FibonacciHeap.merge(fibonacciHeap6, fibonacciHeap6);
	      FibonacciHeap.merge(fibonacciHeap7, fibonacciHeap7);
	      FibonacciHeap<Object, Object> fibonacciHeap8 = FibonacciHeap.create((Comparator<? super Object>) comparator3);
	      fibonacciHeap8.spliterator();
	      FibonacciHeap<Object, Object> fibonacciHeap9 = FibonacciHeap.merge(fibonacciHeap8, fibonacciHeap8);
	      fibonacciHeap0.pollOption();
	      assertEquals(1, fibonacciHeap0.size());
	      
	      FibonacciHeap<String, String> fibonacciHeap10 = FibonacciHeap.create();
	      fibonacciHeap10.peekOption();
	      fibonacciHeap9.iterator();
	      assertEquals(0, fibonacciHeap9.size());
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	     
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      fibonacciHeap0.add("", fibonacciHeap0);
	      fibonacciHeap0.pollOption();
	      assertEquals(2, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	     
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      assertEquals(2, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<Object, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      FibonacciHeap<Object, Integer> fibonacciHeap1 = FibonacciHeap.create();
	      FibonacciHeap<Object, Integer> fibonacciHeap2 = FibonacciHeap.create();
	      Integer integer0 = new Integer(0);
	      fibonacciHeap2.add(fibonacciHeap0, integer0);
	      FibonacciHeap.merge(fibonacciHeap1, fibonacciHeap2);
	      assertEquals(1, fibonacciHeap2.size());
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      // Undeclared exception!
	      try { 
	        FibonacciHeap.merge((FibonacciHeap<String, String>) null, (FibonacciHeap<String, String>) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         
	        
	      }
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      FibonacciHeap<Object, String> fibonacciHeap0 = FibonacciHeap.create();
	      Comparator<String> comparator0 = (Comparator<String>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      
	      FibonacciHeap<Object, String> fibonacciHeap1 = FibonacciHeap.create((Comparator<? super String>) comparator0);
	      // Undeclared exception!
	      try { 
	        FibonacciHeap.merge(fibonacciHeap0, fibonacciHeap1);
	        fail("Expecting exception: IllegalArgumentException");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Heaps that use different comparators can't be merged.
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      // Undeclared exception!
	      try { 
	        fibonacciHeap0.decreasePriority((FibonacciHeap.Entry) null, (Object) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	       
	      }
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      // Undeclared exception!
	      try { 
	        FibonacciHeap.create((Comparator<? super Integer>) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	        
	      }
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<Object, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      // Undeclared exception!
	      try { 
	        fibonacciHeap0.add((Object) null, (Object) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      
	      FibonacciHeap<Object, Integer> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Integer>) comparator0);
	      fibonacciHeap0.comparator();
	      assertEquals(0, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("%jHQ;3;q@qAV&", object0);
	      fibonacciHeap0.add("%jHQ;3;q@qAV&", fibonacciHeap0);
	      fibonacciHeap0.pollOption();
	      assertEquals(2, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	     
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      assertEquals(2, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<Object, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      assertEquals(1, fibonacciHeap0.size());
	      
	      fibonacciHeap0.pollOption();
	      assertEquals(0, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<String, String> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super String>) comparator0);
	      fibonacciHeap0.add("", "");
	      boolean boolean0 = fibonacciHeap0.isEmpty();
	      assertEquals(1, fibonacciHeap0.size());
	      assertFalse(boolean0);
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<String, String> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super String>) comparator0);
	      fibonacciHeap0.add("", "");
	      Consumer<Object> consumer0 = (Consumer<Object>) mock(Consumer.class, new ViolatedAssumptionAnswer());
	      fibonacciHeap0.forEach(consumer0);
	      assertEquals(1, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      int int0 = fibonacciHeap0.size();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	 
	      FibonacciHeap<String, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      fibonacciHeap0.add("", "");
	      Object object0 = new Object();
	      fibonacciHeap0.add("", object0);
	      fibonacciHeap0.add("", fibonacciHeap0);
	      fibonacciHeap0.pollOption();
	      assertEquals(2, fibonacciHeap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      Comparator<Object> comparator0 = (Comparator<Object>) mock(Comparator.class, new ViolatedAssumptionAnswer());
	      FibonacciHeap<Object, Object> fibonacciHeap0 = FibonacciHeap.create((Comparator<? super Object>) comparator0);
	      // Undeclared exception!
	      try { 
	        fibonacciHeap0.remove((FibonacciHeap.Entry) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	        
	     
	      }
	  }

	  @Test(timeout = 4000)
	  public void test18()  throws Throwable  {
	      FibonacciHeap<Object, Integer> fibonacciHeap0 = FibonacciHeap.create();
	      fibonacciHeap0.clear();
	      assertEquals(0, fibonacciHeap0.size());
	  }

	
}

