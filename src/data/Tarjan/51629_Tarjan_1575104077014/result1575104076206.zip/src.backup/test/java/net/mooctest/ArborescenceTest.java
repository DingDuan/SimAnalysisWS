package net.mooctest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArborescenceTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		double[][] doubleArray0 = new double[2][2];
		double[] doubleArray1 = new double[7];
		doubleArray1[1] = (-0.5);
		doubleArray0[0] = doubleArray1;
		
	}

}
